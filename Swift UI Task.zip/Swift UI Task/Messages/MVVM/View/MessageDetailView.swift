//
//  MessageDetailView.swift
//  Messages
//
//

import SwiftUI

struct MessageDetailView: View {
    @Environment(\.managedObjectContext) private var viewContext
    var detail: Message
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var btnBack : some View { Button(action: {
        self.presentationMode.wrappedValue.dismiss()
    }) {
        HStack {
            Image("backIcon") // set image here
                .aspectRatio(contentMode: .fit)
                .foregroundColor(.black)
            Text("Back").foregroundColor(.black)
        }
    }
    }
    
    var body: some View {
        Divider()
        VStack(alignment: .leading, spacing: 10) {
            HStack{
                Text("\(detail.name!)")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.988, green: 0.631, blue: 0.012))
                Text("\((detail.create_date!))")
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    .foregroundColor(.green)
                    .font(.subheadline)
            }
            Divider()
            Text(detail.msg_title!)
                .font(.headline)
                .bold()
                .foregroundColor(.black)
            Text(detail.descp!)
                .font(.subheadline)
                .foregroundColor(.gray)
                .lineLimit(100)
                .frame(maxWidth: .infinity, alignment: .center)

        }.padding()
        .frame(minWidth: 0, maxHeight: .infinity, alignment: .topLeading)
        .navigationBarTitle("", displayMode: .inline)
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading: btnBack, trailing:
                                
                                HStack{
                                    Image("upArrow").imageScale(.large)
                                        .padding(10)
                                    Image("downArrow").imageScale(.large)
                                        .padding(10)
                                    Image("refresh").imageScale(.medium)
                                        .padding(10)
                                })
        .onAppear { updateUnreadVal() }
    }
    
    func updateUnreadVal(){
        if detail.read_flag == 0{
            detail.setValue(1, forKey: "read_flag")
            do {
                try viewContext.save()
            } catch {
                // handle the Core Data error
            }
        }
    }
}


