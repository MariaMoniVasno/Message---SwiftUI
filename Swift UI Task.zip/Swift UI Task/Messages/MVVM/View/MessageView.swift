//
//  MessageView.swift
//  Messages
//

import SwiftUI
import CoreData

struct MessageView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        entity: Message.entity(),
        sortDescriptors: [NSSortDescriptor(keyPath: \Message.msg_id, ascending: true)],
        animation: .default)
    private var sortedMsg: FetchedResults<Message>
    @State private var searchText = ""
    @State private var selectorIndex = 0
    @State private var segmntContTxt = ["ALL","UNREAD"]
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var btnBack : some View { Button(action: {
        self.presentationMode.wrappedValue.dismiss()
    }) {
        HStack {
            Image("backIcon") // set image here
                .aspectRatio(contentMode: .fit)
                .foregroundColor(.black)
            Text("Home").foregroundColor(.black)
        }
    }
    }
    
    var body: some View {
        ZStack{
            //Search
            VStack(alignment: .leading, spacing: 5) {
                SearchBar(text: $searchText, placeholder: "Search")
                    .padding(.top, 5)
                    .background(Color(red: 0.878, green: 0.878, blue: 0.878))
                HStack {
                    //Segment Control
                    Picker("", selection: $selectorIndex) {
                        ForEach(0 ..< segmntContTxt.count) { index in
                            Text(self.segmntContTxt[index]).tag(index)
                        } // Picker
                    } // ForEach
                    .padding(.trailing, 10)
                    .frame(maxWidth: 150, alignment: .trailing)
                    .pickerStyle(SegmentedPickerStyle())
                } // HStack
                .frame(minWidth: 0,maxWidth: .infinity,minHeight: 0,maxHeight: 50,alignment: .trailing)
                .background(Color.gray)
                if selectorIndex == 0 { // All
                    List {
                        ForEach(sortedMsg.filter {
                            self.searchText.isEmpty ?
                                true : 
                                ("\(String(describing: $0.name))".lowercased().contains(self.searchText.lowercased()) || "\(String(describing: $0.descp))".lowercased().contains(self.searchText.lowercased()) || "\(String(describing: $0.msg_title))".lowercased().contains(self.searchText.lowercased()))
                        }, id: \.self) { item in
                            NavigationLink(destination: MessageDetailView(detail:item)){
                                MessagePage(message: item)
                            }// navigation
                            .listRowBackground(item.read_flag == 1 ? Color(.white) : Color(red: 0.878, green: 0.878, blue: 0.878))
                        }// for each
                        .onDelete(perform: deleteMessages)
                    }// List
                    .listStyle(InsetListStyle())
                    .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
                } else { // Unread
                    
                    let internalFilter = sortedMsg.filter{
                        $0.read_flag == 0
                    }
                    List{
                        ForEach(internalFilter.filter {
                            self.searchText.isEmpty ?
                                true :
                                (("\(String(describing: $0.name))".lowercased().contains(self.searchText.lowercased()) || "\(String(describing: $0.descp))".lowercased().contains(self.searchText.lowercased()) || "\(String(describing: $0.msg_title))".lowercased().contains(self.searchText.lowercased())))
                        }, id: \.self) { item in
                            NavigationLink(destination: MessageDetailView(detail:item)){
                                MessagePage(message: item)
                            }// navigation
                            .listRowBackground( Color(red: 0.878, green: 0.878, blue: 0.878))
                        }// for each
                        .onDelete(perform: deleteMessages)
                    } //List
                    .listStyle(InsetListStyle())
                    .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
                }
            }//VStack
        }//ZStack
        .navigationBarTitle("", displayMode: .inline)
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading: btnBack, trailing:
                                Image("refresh").imageScale(.medium)
        )
    }//View
    
    
    init() {
        UISegmentedControl.appearance().selectedSegmentTintColor = UIColor(red: 230/255, green: 143/255, blue: 9/255, alpha: 1.0)
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor(red: 230/255, green: 143/255, blue: 9/255, alpha: 1.0)], for: .normal)
        UISegmentedControl.appearance().backgroundColor = UIColor.white
        UITableView.appearance().allowsSelection = false
        UITableViewCell.appearance().selectionStyle = .none
    }
    
    // Deleting the message
    func deleteMessages(at offsets: IndexSet) {
        for index in offsets {
            let language = sortedMsg[index]
            viewContext.delete(language)
            language.setValue("0", forKey: "supp_date")
            do {
                try viewContext.save()
            } catch {
                // handle the Core Data error
            }
        }
    }
    
    //Dynamic Message Design
    struct MessageInformation: View {
        var message: Message
        var body: some View {
            HStack{
                if message.read_flag == 1 {
                    Circle()
                        .fill(Color(red: 230/255, green: 143/255, blue: 9/255))
                        .frame(width: 10, height: 10) }
                Text("\(message.name!)")
                    .foregroundColor(Color(red: 230/255, green: 143/255, blue: 9/255))
                Text("\((message.create_date!))")
                    
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    .foregroundColor(.green)
            }// HStack
            Text("\(message.msg_title!)")
                .foregroundColor(.black)
            Text("\(message.descp!)")
                .foregroundColor(.gray)
                .lineLimit(1)
        }
    }
    
    struct MessagePage: View {
        var message: Message
        var body: some View {
            VStack(alignment: .leading, spacing:5) {
                MessageInformation(message: message)
            }// VStack
            .font(.subheadline)
        }
    }
}

struct MessageView_Previews: PreviewProvider {
    static var previews: some View {
        MessageView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}

// SearchBar
struct SearchBar: UIViewRepresentable {
    
    @Binding var text: String
    var placeholder: String
    
    class Coordinator: NSObject, UISearchBarDelegate {
        @Binding var text: String
        init(text: Binding<String>) {
            _text = text
        }
        func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            text = searchText
        }
    }
    
    func makeCoordinator() -> SearchBar.Coordinator {
        return Coordinator(text: $text)
    }
    
    func makeUIView(context: UIViewRepresentableContext<SearchBar>) -> UISearchBar {
        let searchBar = UISearchBar(frame: .zero)
        searchBar.delegate = context.coordinator
        searchBar.placeholder = placeholder
        searchBar.searchBarStyle = .minimal
        searchBar.autocapitalizationType = .none
        searchBar.searchTextField.backgroundColor = UIColor.white
        return searchBar
    }
    
    func updateUIView(_ uiView: UISearchBar, context: UIViewRepresentableContext<SearchBar>) {
        if (uiView.text?.count)! > 0 {
            guard let searchText = uiView.text,
                  searchText != "" else {
                return
            }
        }
    }
}

