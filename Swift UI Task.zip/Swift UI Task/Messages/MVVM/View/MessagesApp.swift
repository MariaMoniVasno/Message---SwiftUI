//
//  MessagesApp.swift
//  Messages
//
//

import SwiftUI

@main
struct MessagesApp: App {
    let persistenceController = PersistenceController.shared
    
    var body: some Scene {
        WindowGroup {
            IntroView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
