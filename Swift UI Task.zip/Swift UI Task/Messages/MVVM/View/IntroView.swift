//
//  IntroView.swift
//  Messages
//


import SwiftUI

struct IntroView: View {
    @ObservedObject var viewModel = MessageViewModel()
    @State private var isDataLoaded = UserDefaults.standard.bool(forKey: "isDataLoaded")
    
    var body: some View {
        NavigationView {
            NavigationLink(destination: MessageView()) {
                VStack{
                    HStack {
                        Image(systemName: "mail")
                        Text("Messages")
                    }.onAppear {
                        if !isDataLoaded {
                            viewModel.readJsonFile()
                            UserDefaults.standard.set(true, forKey: "isDataLoaded")
                        }
                    }
                    .padding()
                    .font(.title3)
                    .foregroundColor(.white)
                    .background(Color(red: 230/255, green: 143/255, blue: 9/255))
                    .cornerRadius(5)

                }
            }
            .navigationBarTitle("", displayMode: .inline)
        }
    }
}

struct IntroView_Previews: PreviewProvider {
    static var previews: some View {
        IntroView()
    }
}
