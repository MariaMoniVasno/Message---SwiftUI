//
//  MessageViewModel.swift
//  Messages
//
//

import Foundation
import CoreData

class MessageViewModel:ObservableObject {
    var dateString = ""
    var newMsgs:[MessageModel.messageLists]? {
        didSet {
            // Remove all Previous Records
            DatabaseController.deleteMessages()
            // Add the new spots to Core Data Context
            self.addNewMessagesToCoreData(self.newMsgs!)
            // Save them to Core Data
            DatabaseController.saveContext()
        }
    }
    
    //MARK:- Date Formatter
    func createDateTxt(dateTxt : String){
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US")
        formatter.dateFormat = "MM-dd-yyyy HH:mm a"
        formatter.amSymbol = "AM"
        formatter.pmSymbol = "PM"
        let date = formatter.date(from: dateTxt)
        
        let relativeFormatter = buildFormatter(locale: Locale(identifier: "en_US"), hasRelativeDate: true)
        let relativeDateString = dateFormatterToString(relativeFormatter, date!)
        // "Jan 18, 2018"
        
        let nonRelativeFormatter = buildFormatter(locale: Locale(identifier: "en_US"))
        let normalDateString = dateFormatterToString(nonRelativeFormatter, date!)
        // "Jan 18, 2018"
        
        let customFormatter = buildFormatter(locale: Locale(identifier: "en_US"), dateFormat: "MM-dd-yyyy" )
        let customDateString = dateFormatterToString(customFormatter, date!)
        // "18 January"
        
        if relativeDateString == normalDateString {
            dateString = customDateString
            print("Use custom date \(customDateString)") // Jan 18
        } else {
            if relativeDateString == "Today"{
            let todayFormatter = buildFormatter(locale: Locale(identifier: "en_US"), dateFormat: "HH:mm a")
            let todayDateString = dateFormatterToString(todayFormatter, date!)
            dateString = todayDateString
            }else{
            dateString = relativeDateString
            }
            print("Use relative date \(relativeDateString)") // Today, Yesterday
        }
    }
    
    func buildFormatter(locale: Locale, hasRelativeDate: Bool = false, dateFormat: String? = nil) -> DateFormatter {
        let formatter = DateFormatter()
        formatter.timeStyle = .none
        formatter.dateStyle = .medium
        if let dateFormat = dateFormat { formatter.dateFormat = dateFormat }
        formatter.doesRelativeDateFormatting = hasRelativeDate
        formatter.locale = locale
        return formatter
    }
    
    func dateFormatterToString(_ formatter: DateFormatter, _ date: Date) -> String {
        return formatter.string(from: date)
    }
    
    //MARK:- addNewMessagesToCoreData
    func addNewMessagesToCoreData(_ msgs: [MessageModel.messageLists]) {
        for msg in msgs {
            let entity = NSEntityDescription.entity(forEntityName: "Message", in: DatabaseController.getContext())
            let newMsg = NSManagedObject(entity: entity!, insertInto: DatabaseController.getContext())
            // Set the data to the entity
            newMsg.setValue(msg.msg_id, forKey: "msg_id")
            newMsg.setValue(msg.name, forKey: "name")
            newMsg.setValue(msg.msg_title, forKey: "msg_title")
            newMsg.setValue(msg.descp, forKey: "descp")
            createDateTxt(dateTxt : msg.create_date!)
            newMsg.setValue(dateString, forKey: "create_date")
            newMsg.setValue(msg.supp_date, forKey: "supp_date")
            newMsg.setValue(msg.read_flag, forKey: "read_flag")
        }
    }
    
    //MARK:- readJsonFile
    func readJsonFile() {
        if let path = Bundle.main.path(forResource: "MessageData", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                do {
                    let decoder = JSONDecoder()
                    let gitData = try decoder.decode(MessageModel.self, from: data)
                    newMsgs = gitData.messageList
                } catch {
                    print(error)
                }
            } catch {
                // handle error
            }
        }
    }
}

class DatabaseController {
    
    private init() {}
    //MARK: getContext
    //Returns the current Persistent Container for CoreData
    class func getContext () -> NSManagedObjectContext {
        return DatabaseController.persistentContainer.viewContext
    }
    
    //MARK: persistentContainer
    static var persistentContainer: NSPersistentContainer = {
        //The container that holds both data model entities
        let container = NSPersistentContainer(name: "Messages")
        
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
            
            
        })
        return container
    }()
    
    // MARK: - Core Data Saving support
    class func saveContext() {
        let context = self.getContext()
        if context.hasChanges {
            do {
                try context.save()
                
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    class func getAllMsg() -> Array<Message> {
        let all = NSFetchRequest<Message>(entityName: "Message")
        var allMsgs = [Message]()
        let sortDescriptor = NSSortDescriptor(key: "msg_id", ascending: true)
        all.sortDescriptors = [sortDescriptor]
        
        do {
            let fetched = try DatabaseController.getContext().fetch(all)
            allMsgs = fetched
        } catch {
            let nserror = error as NSError
            //TODO: Handle Error
            print(nserror.description)
        }
        
        return allMsgs
    }
    
    class func deleteMessages() {
        do {
            let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Message")
            let deleteALL = NSBatchDeleteRequest(fetchRequest: deleteFetch)
            
            try DatabaseController.getContext().execute(deleteALL)
            DatabaseController.saveContext()
        } catch {
            print ("There is an error in deleting records")
        }
    }
}
