//
//  MessageModel.swift
//  Messages
//

import Foundation

struct MessageModel: Codable {
    var messageList:[messageLists]?
        enum CodingKeys: String, CodingKey {
        case messageList = "messageList"
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        messageList = try values.decode([messageLists].self, forKey: .messageList)
    }
    struct messageLists:Codable {
        var msg_id: Int32?
        var name: String?
        var msg_title: String?
        var descp: String?
        var create_date : String?
        var supp_date : String?
        var read_flag : Int32?
    }
}
